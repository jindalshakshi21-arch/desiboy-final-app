import { Router } from "express";
import { authStore } from "../lib/authStore";

const router = Router();

router.post("/login", (req, res) => {
  const { username, password } = req.body as { username?: string; password?: string };
  if (!username || !password) {
    res.status(400).json({ ok: false, error: "Username aur password dono zaroori hain." });
    return;
  }
  const creds = authStore.getCredentials();
  if (username.trim() !== creds.username || password !== creds.password) {
    res.status(401).json({ ok: false, error: "Username ya password galat hai. Dobara try karein." });
    return;
  }
  res.json({ ok: true, version: creds.version });
});

router.get("/version", (_req, res) => {
  const { version } = authStore.getCredentials();
  res.json({ version });
});

export default router;
