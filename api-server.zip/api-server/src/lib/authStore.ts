import { randomUUID } from "node:crypto";

interface StoreState {
  username: string;
  password: string;
  version: string;
}

// आपकी बिल्कुल नई Firebase Project ID
const FIREBASE_PROJECT_ID = "desiboy-app"; 
const DOCUMENT_URL = `https://googleapis.com{FIREBASE_PROJECT_ID}/databases/(default)/documents/desiboy_creds/current`;

let store: StoreState = {
  username: "desiboy",
  password: "meter@2026",
  version: "v1",
};

async function fetchFromFirebase() {
  try {
    const res = await fetch(DOCUMENT_URL);
    if (res.ok) {
      const data = await res.json();
      if (data && data.fields) {
        store = {
          username: data.fields.username?.stringValue || "desiboy",
          password: data.fields.password?.stringValue || "meter@2026",
          version: data.fields.version?.stringValue || "v1",
        };
      }
    }
  } catch (e) {
    console.error("Firebase se data load karne me error:", e);
  }
}

fetchFromFirebase();
setInterval(fetchFromFirebase, 30000);

export const authStore = {
  getCredentials: (): StoreState => {
    return { ...store };
  },

  updateCredentials: (username: string, password: string): string => {
    const newVersion = "v-" + randomUUID().slice(0, 8);
    const cleanedUsername = username.trim();
    
    store = { username: cleanedUsername, password, version: newVersion };

    const payload = {
      fields: {
        username: { stringValue: cleanedUsername },
        password: { stringValue: password },
        version: { stringValue: newVersion }
      }
    };

    fetch(DOCUMENT_URL, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    }).catch((e) => console.error("Firebase par save karne me error:", e));

    return newVersion;
  },

  generateAdminToken: (): string => {
    return randomUUID();
  },
};

